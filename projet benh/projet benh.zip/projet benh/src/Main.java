import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Date;

public class Main {
    public static void main(String[] args) throws Exception {
        Taquin test = new Taquin("D:\\cours\\L3/\\ia benhs\\projet benh\\src\\tester-3x3d",3);
        parcours_largeur parcoursDFS = new parcours_largeur(15);
        parcours_profondeur parcoursBFS = new parcours_profondeur(21);

//        Taquin test2 = test.Translation("haut");
//        Taquin test3 = test2.Translation("bas");

       long timer = System.nanoTime();
       ArrayList<Taquin> res = parcoursBFS.solve(test);
       System.out.println(System.nanoTime()-timer + " temps");
       System.out.println("test " + "\n" + test);
       System.out.println("res " + "\n" + res);
    }
}